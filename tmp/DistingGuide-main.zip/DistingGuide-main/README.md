# Disting mk4 Quick Guide

Browser-based quick reference guide for the [Experts Sleepers Disting mk4](http://www.expert-sleepers.co.uk/disting.html). Is available online at [distingquickguide.rustle.works](http://distingquickguide.rustle.works).
